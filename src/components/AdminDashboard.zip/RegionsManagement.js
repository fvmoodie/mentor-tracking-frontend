import { useState, useEffect } from "react";
import { Button, Input, Label, Card, CardContent, Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui";
import { Modal } from "@/components/ui/modal";

const API_URL = "http://167.71.169.127:5000/regions";

export default function RegionsManagement() {
  const [regions, setRegions] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [currentRegion, setCurrentRegion] = useState({ RegionID: null, RegionName: "", Description: "" });

  useEffect(() => {
    fetchRegions();
  }, []);

  const fetchRegions = async () => {
    try {
      const response = await fetch(API_URL);
      const data = await response.json();
      setRegions(data.regions);
    } catch (error) {
      console.error("Error fetching regions:", error);
    }
  };

  const handleSave = async () => {
    try {
      const method = currentRegion.RegionID ? "PUT" : "POST";
      const url = currentRegion.RegionID ? `${API_URL}/${currentRegion.RegionID}` : API_URL;

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          RegionName: currentRegion.RegionName,
          Description: currentRegion.Description,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to save region");
      }
      fetchRegions();
      setModalOpen(false);
      setCurrentRegion({ RegionID: null, RegionName: "", Description: "" });
    } catch (error) {
      console.error("Error saving region:", error);
    }
  };

  const handleEdit = (region) => {
    setCurrentRegion(region);
    setModalOpen(true);
  };

  const handleDelete = async (RegionID) => {
    try {
      const response = await fetch(`${API_URL}/${RegionID}`, { method: "DELETE" });
      if (!response.ok) {
        throw new Error("Failed to delete region");
      }
      fetchRegions();
    } catch (error) {
      console.error("Error deleting region:", error);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">User Management - Create Regions</h1>
      <Button className="my-4" onClick={() => setModalOpen(true)}>Add Region</Button>
      <Card>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {regions.map((region) => (
                <TableRow key={region.RegionID}>
                  <TableCell>{region.RegionID}</TableCell>
                  <TableCell>{region.RegionName}</TableCell>
                  <TableCell>{region.Description}</TableCell>
                  <TableCell>
                    <Button size="sm" onClick={() => handleEdit(region)}>Edit</Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDelete(region.RegionID)}>Delete</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      {modalOpen && (
        <Modal onClose={() => setModalOpen(false)}>
          <h2>{currentRegion.RegionID ? "Edit Region" : "Add Region"}</h2>
          <Label>Region Name</Label>
          <Input
            value={currentRegion.RegionName}
            onChange={(e) => setCurrentRegion({ ...currentRegion, RegionName: e.target.value })}
          />
          <Label>Description</Label>
          <Input
            value={currentRegion.Description}
            onChange={(e) => setCurrentRegion({ ...currentRegion, Description: e.target.value })}
          />
          <Button onClick={handleSave}>Save</Button>
        </Modal>
      )}
    </div>
  );
}
